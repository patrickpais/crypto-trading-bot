import type { Express, Request, Response } from "express";
import { getSessionCookieOptions } from "./cookies";
import { COOKIE_NAME, ONE_YEAR_MS } from "../../shared/const";

// Simple in-memory user store (in production, use database)
const users: Record<string, { password: string; name: string }> = {
  admin: { password: "admin123", name: "Admin User" },
  patrick: { password: "Gabi2205", name: "Patrick Pais" },
};

export function registerSimpleAuthRoutes(app: Express) {
  // Login endpoint
  app.post("/api/auth/login", (req: Request, res: Response) => {
    console.log("[SimpleAuth] Login attempt", req.body);
    const { username, password } = req.body;

    if (!username || !password) {
      res.status(400).json({ error: "Username and password required" });
      return;
    }

    const user = users[username];
    if (!user || user.password !== password) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }

    // Create a simple session token
    const sessionToken = JSON.stringify({
      username,
      name: user.name,
      timestamp: Date.now(),
    });

    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(COOKIE_NAME, sessionToken, {
      ...cookieOptions,
      maxAge: ONE_YEAR_MS,
    });

    res.json({
      success: true,
      user: { username, name: user.name },
    });
  });

  // Logout endpoint
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    res.json({ success: true });
  });

  // Get current user
  app.get("/api/auth/me", (req: Request, res: Response) => {
    const cookie = req.cookies[COOKIE_NAME];
    if (!cookie) {
      res.status(401).json({ error: "Not authenticated" });
      return;
    }

    try {
      const session = JSON.parse(cookie);
      res.json({
        id: 1,
        username: session.username,
        name: session.name,
        email: `${session.username}@example.com`,
        role: "user",
      });
    } catch {
      res.status(401).json({ error: "Invalid session" });
    }
  });
}
